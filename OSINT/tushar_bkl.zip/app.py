# app.py
from flask import Flask, render_template
from datetime import datetime

app = Flask(__name__)

# Sample blog posts
POSTS = [
    {
        'title': 'My Flight to Past',
        'id':1,
        'date': datetime(2025, 1, 22),
        'category': 'chess',
        'content': """
            On Flight VJH643, at 1:18 AM, I found myself lost in thought, staring out at the dark expanse below. My mind drifted back to a historic chess match from 1981, played somewhere beneath these very skies. The contenders? A Grandmaster world champion and his tenacious rival, battling in a game that has since become the stuff of legend.
            Inspired by the Grandmaster’s brilliance, I set up my miniature chessboard and played the opening he was renowned for. Each move resonated with echoes of the past, but the climax—the final three moves—eluded me.
            Can you uncover them? The truth lies somewhere in the archives of chess history. The answer is a challenge for the observant, the curious, and those who dare to delve into the game’s intricate beauty.
            As the plane began its descent, I smiled, knowing some mysteries are meant to be solved by those who seek them.""",
        'author': ' Stacy Pathak',
        'read_time': '5 min'
    },
    {
        'title': 'How Neural Networks are Revolutionizing Chess Engines',
        'id':2,        
        'date': datetime(2024, 2, 8),
        'category': 'tech',
        'content': 'The integration of neural networks in modern chess engines has fundamentally changed how computers approach the game...',
        'author': 'Dr. Alex Kumar',
        'read_time': '8 min'
    },
    {
        'title': 'The Rise of Quantum Computing',
        'id':3,
        'date': datetime(2024, 2, 5),
        'category': 'tech',
        'content': 'Quantum computing is poised to revolutionize the way we process information...',
        'author': 'Prof. Maria Rodriguez',
        'read_time': '6 min'
    }
]

@app.route('/')
def home():
    return render_template('home.html', posts=POSTS)


@app.route('/about')
def about():
    return render_template('about.html')

@app.route('/post/<int:post_id>')
def post(post_id):
    post = next((post for post in POSTS if post['id'] == post_id), None)
    if post is None:
        abort(404)
    return render_template('post.html', post=post)

if __name__ == '__main__':
    app.run(debug=True)